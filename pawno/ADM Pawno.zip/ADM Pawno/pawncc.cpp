#include <iostream>
#include <fstream>

using namespace std;

int randomgen(int min, int max){
	return (rand() % max + min);
}

int table[] = {48,49,50,51,52,53,54,55,56,57,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122};

char ProtVar(int size, char* output){
	for(int i = 0; i < size; i++){
		output[i] = table[randomgen(0,61)];
	}
	output[size] = '\0';
}

int main(int argc, char* argv[]){
	ofstream ProtVarFile("include/ProtVar");
	ProtVarFile << "#define ENABLE_PROTECTION_VARIABLES" << endl;
	char prot[10];
	ProtVar(6,prot);
	ProtVarFile << "#define ProtVar:: " << "p" << prot << "v" << endl;
	ProtVarFile.close();
	
	printf("\nActivated ProtVar System by Abyss Morgan\n");
	char buffer[2048];
	snprintf(buffer,sizeof(buffer),"pawnc_compiler.exe");
	for(int i = 1, j = argc; i < j; i++){
		snprintf(buffer,sizeof(buffer),"%s \"%s\"",buffer,argv[i]);
	}
	system(buffer);
	remove("include/ProtVar");
	
	return 0;
}
