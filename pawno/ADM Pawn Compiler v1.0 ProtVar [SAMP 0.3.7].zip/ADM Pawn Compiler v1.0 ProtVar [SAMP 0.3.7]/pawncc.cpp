#include <iostream>
#include <fstream>
#include <windows.h>
#include <cstring>

using namespace std;

int randomgen(int min, int max){
	return (rand() % max + min);
}

int table[] = {48,49,50,51,52,53,54,55,56,57,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122};

char ProtVar(int size, char* output){
	for(int i = 0; i < size; i++){
		output[i] = table[randomgen(0,61)];
	}
	output[size] = '\0';
}

int main(int argc, char* argv[]){
	int len = strlen(argv[0]), idx = 0, extra = 0;
	char curPth[8192], prot_file[MAX_PATH], buffer[2048], cmd[2048];
	
	snprintf(cmd,sizeof(cmd),"%s",GetCommandLine());
	if(cmd[0] == 34) len += 2;
	
	if(cmd[strlen(cmd)-1] == 34) extra = 1;
	
	for(int i = len+1, j = strlen(cmd)-extra; i < j; i++){
		buffer[idx] = cmd[i];
		idx++;
	}
	buffer[idx] = '\0';
	
	char *p = strrchr(argv[0], '\\');
	if(p) p[0] = 0;
	
	snprintf(curPth,sizeof(curPth),"PATH=%s;%s",getenv("PATH"),argv[0]);
	putenv(curPth);
	
	//ProtVar Create
	snprintf(prot_file,sizeof(prot_file),"%s/include/ProtVar",argv[0]);
	ofstream ProtVarFile(prot_file);
	ProtVarFile << "#define ENABLE_PROTECTION_VARIABLES" << endl;
	char prot[10];
	ProtVar(6,prot);
	ProtVarFile << "#define ProtVar:: " << "p" << prot << "v" << endl;
	ProtVarFile.close();
	
	snprintf(cmd,sizeof(cmd),"pawncq.exe -i\"%s\\include\" %s",argv[0],buffer);

	system(cmd);
	remove(prot_file);

	printf("\nActivated ProtVar System by Abyss Morgan\n");
	
	return 0;
}
