SA-MP Streamer Plugin v2.7.8
============================

Preface
-------

This plugin streams objects, pickups, checkpoints, race checkpoints,
map icons, and 3D text labels at user-defined server ticks. Basic
area detection is also included. Because it is written entirely in
C++, much of the overhead from PAWN is avoided. This streamer, as a
result, is quite a bit faster than any other implementation currently
available in PAWN.

Documentation
-------------

Refer to the GitHub Wiki for more information.
