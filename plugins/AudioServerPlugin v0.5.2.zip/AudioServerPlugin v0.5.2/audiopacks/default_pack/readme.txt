In the sample audio.ini file, all mapped files under the section
labeled "default_pack" (file.mp3, file.ogg, and file.wav) need to be
in this folder.
